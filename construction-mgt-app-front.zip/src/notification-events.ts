// notification-events.ts
export const NOTIFICATION_EVENT = {
  PUSH: "notification",
};
