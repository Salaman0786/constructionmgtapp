import React, { useState, useEffect, useRef } from "react";
import { X, Calendar, ChevronDown } from "lucide-react";
import {
  useCreateProjectMutation,
  useGetProjectManagersQuery,
  useGetProjectByIdQuery,
  useUpdateProjectMutation,
  useLazyGetAllUsersQuery,
  useGetAllUsersQuery,
} from "../../../features/projectControll/projectsApi";
import { showError, showInfo, showSuccess } from "../../../utils/toast";
import { useSelector } from "react-redux";
import { validateProject } from "../../../utils/validators/projectValidator";
import { RequiredLabel } from "../../common/RequiredLabel";

interface AddEditProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  projectId?: string | null; // if present → edit mode
}

interface ProjectForm {
  code: string; // ✅ Add this
  name: string;
  type: string;
  city: string;
  country: string;
  address: string;
  startDate: string;
  endDate: string;
  status: string;
  budgetBaseline: string | number;
  currency: string;
  managerId: string;
}

const AddEditProjectModal: React.FC<AddEditProjectModalProps> = ({
  isOpen,
  onClose,
  projectId,
}) => {
  const isEdit = Boolean(projectId);
  const [errors, setErrors] = useState<Record<string, string>>({});

  /* -----------------------------------------
        API HOOKS
  ----------------------------------------- */

  const {
    data: managerData,
    isLoading: isManagersLoading,
    refetch: refetchManagers,
  } = useGetProjectManagersQuery(undefined);

  const { data: projectDetails, isFetching: isProjectFetching } =
    useGetProjectByIdQuery(projectId!, {
      refetchOnMountOrArgChange: true,
    });
  const [createProject, { isLoading: creating }] = useCreateProjectMutation();
  const [updateProject, { isLoading: updating }] = useUpdateProjectMutation();
  const [open, setOpen] = useState(false);
  const loading = creating || updating;

  /* -----------------------------------------
      DEFAULT FORM VALUES
  ----------------------------------------- */
  const initialForm: ProjectForm = {
    code: "",
    name: "",
    type: "",
    city: "",
    country: "",
    address: "",
    startDate: "",
    endDate: "",
    status: "PLANNING",
    budgetBaseline: "",
    currency: "ETB",
    managerId: "",
  };

  const [form, setForm] = useState<ProjectForm>(initialForm);

  /* -----------------------------------------
      MANAGER DROPDOWN STATE
  ----------------------------------------- */
  const managers = managerData?.data?.managers || [];
  const [managerSearch, setManagerSearch] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const userRole = useSelector((state: any) => state.auth.user?.role?.name);
  const isManager = userRole === "MANAGER";
  const isSuperAdmin = userRole === "SUPER_ADMIN";
  const cleanedSearch = managerSearch.trim().toLowerCase();
  const filteredManagers = managers.filter((m: any) =>
    m.fullName.toLowerCase().includes(cleanedSearch)
  );
  const [selected, setSelected] = useState([]);
  // const { data: patientResponse } = useGetAllUsersQuery({ page: 0, limit: 50 });
  const { data: patientResponse, refetch } = useGetAllUsersQuery(
    {
      page: 0,
      limit: 50,
    },
    { skip: !isManager }
  );
  useEffect(() => {
    setSelected(projectDetails?.data?.assignedUsers);
  }, [projectDetails]);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const dropdownRefUser = useRef<HTMLDivElement>(null);
  /* -----------------------------------------
      RESET FORM WHEN ENTERING CREATE MODE
  ----------------------------------------- */
  useEffect(() => {
    if (!isEdit && isOpen) {
      setForm(initialForm);
      setManagerSearch("");
      setHighlightIndex(-1);
    }
  }, [isEdit, isOpen]);

  /* -----------------------------------------
      RESET Errors WHEN CLose Or Cancel Modal
  ----------------------------------------- */

  useEffect(() => {
    if (!isOpen) {
      setErrors({});
    }
  }, [isOpen]);

  /* -----------------------------------------
      PREFILL FORM IN EDIT MODE
  ----------------------------------------- */
  useEffect(() => {
    if (isEdit && projectDetails?.data) {
      const p = projectDetails.data;

      setForm({
        code: p.code,
        name: p.name,
        type: p.type,
        city: p.city,
        country: p.country,
        address: p.address,
        startDate: p.startDate.split("T")[0],
        endDate: p.endDate.split("T")[0],
        status: p.status,
        budgetBaseline: p.budgetBaseline,
        currency: p.currency,
        managerId: p.manager?.id || "",
      });

      setManagerSearch(p.manager?.fullName || "");
      setHighlightIndex(-1);
    }
  }, [projectDetails, isEdit]);

  /* -----------------------------------------
      OUTSIDE CLICK TO CLOSE DROPDOWN
  ----------------------------------------- */
  useEffect(() => {
    const handler = (e: any) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  /* -----------------------------------------
      ON INPUT CHANGE
  ----------------------------------------- */
  // const handleChange = (
  //   e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  // ) => {
  //   setForm({ ...form, [e.target.name]: e.target.value });
  // };
  const handleCheckboxChange = (item) => {
    if (selected.some((s) => s.id === item.id)) {
      setSelected((prev) => prev.filter((s) => s.id !== item.id));
    } else {
      setSelected((prev) => [...prev, item]);
    }
  };
  useEffect(() => {
    function handleClickOutside(e) {
      if (
        dropdownRefUser.current &&
        !dropdownRefUser.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };
  const removeTag = (id) => {
    setSelected((prev) => prev.filter((item) => item.id !== id));
  };
  /* -----------------------------------------
      SELECT MANAGER
  ----------------------------------------- */
  const handleSelectManager = (manager: any) => {
    setManagerSearch(manager.fullName);
    setForm({ ...form, managerId: manager.id });
    setShowDropdown(false);

    setErrors((prev) => ({ ...prev, managerId: "" }));
  };

  /* -----------------------------------------
      SUBMIT FORM
  ----------------------------------------- */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const validationErrors = validateProject(form, isEdit);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      showInfo("Please fill all required fields.");
      return;
    }

    const payload = {
      ...form,
      budgetBaseline: Number(form.budgetBaseline),
    };
    const payloadUpdate = {
      ...form,
      budgetBaseline: Number(form.budgetBaseline),
      assignedUserIds: selected?.map((item) => String(item.id)),
    };
    // ❌ Remove code only during CREATE
    if (!isEdit) {
      delete payload.code;
    }

    try {
      if (isEdit) {
        await updateProject({ id: projectId, payload: payloadUpdate }).unwrap();
        showSuccess("Project updated successfully!");
      } else {
        await createProject(payload).unwrap();
        showSuccess("Project created successfully!");

        // Reset form after create
        setForm(initialForm);
        setManagerSearch("");
      }

      onClose();
    } catch (error: any) {
      const msg = Array.isArray(error?.data?.message)
        ? error.data.message.join(", ")
        : error?.data?.message;

      showError(
        msg === "managerId must be a UUID"
          ? "Invalid manager selected. Please choose from the list."
          : msg || "Something went wrong."
      );
    }
  };

  /* -----------------------------------------
      UI
  ----------------------------------------- */

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/40 p-4">
      <div className="relative bg-white rounded-lg shadow-lg w-full max-w-[350px] sm:max-w-lg p-6 max-h-[90vh] overflow-y-auto">
        {/* HEADER */}
        <div className="flex justify-between items-center border-b pb-3">
          <h2 className="text-lg font-semibold text-gray-800">
            {isEdit ? "Edit Project" : "Create New Project"}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={20} />
          </button>
        </div>

        {/* EDIT MODE LOADING SPINNER */}
        {isEdit && isProjectFetching && (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-3 border-[#4b0082]"></div>
          </div>
        )}

        {/* FORM */}
        {!isProjectFetching && (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            <div
              className={`grid grid-cols-1 ${
                isEdit ? "sm:grid-cols-2 gap-4" : "sm:grid-cols-1"
              }`}
            >
              {/*Project Code*/}
              {isEdit && (
                <div>
                  <RequiredLabel label="Project Code" />
                  <input
                    type="text"
                    value={form.code}
                    disabled
                    className="w-full mt-1 border border-gray-300 bg-gray-100 cursor-not-allowed rounded-md p-2 text-sm
      focus:outline-none"
                  />
                </div>
              )}

              {/* NAME */}
              <div>
                <RequiredLabel label="Project Name" />
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  placeholder="Enter project name"
                  onChange={handleChange}
                  disabled={isManager}
                  className={`w-full mt-1 border border-gray-300 ${
                    isManager ? "cursor-not-allowed bg-gray-100" : ""
                  } rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]`}
                />
                {errors.name && (
                  <p className="text-red-500 text-xs mt-1">{errors.name}</p>
                )}
              </div>
            </div>

            {/* TYPE + STATUS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <RequiredLabel label="Project Type" />
                <input
                  type="text"
                  name="type"
                  value={form.type}
                  placeholder="Residential / Commercial"
                  onChange={handleChange}
                  className="w-full mt-1 border border-gray-300 rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]"
                />
                {errors.type && (
                  <p className="text-red-500 text-xs mt-1">{errors.type}</p>
                )}
              </div>

              <div>
                <RequiredLabel label="Status" />
                <select
                  name="status"
                  value={form.status}
                  onChange={handleChange}
                  className="w-full mt-1 border border-gray-300 rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]"
                >
                  <option value="PLANNING">Planning</option>
                  <option value="ONGOING">Ongoing</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="ON_HOLD">On Hold</option>
                </select>
              </div>
            </div>

            {/* MANAGER SEARCH */}
            <div className="relative" ref={dropdownRef}>
              <RequiredLabel label="Project Manager" />

              <input
                type="text"
                value={managerSearch}
                placeholder="Search manager..."
                disabled={isEdit}
                onChange={(e) => {
                  setManagerSearch(e.target.value.trimStart());
                  setShowDropdown(true);
                  // ✅ CLEAR MANAGER ERROR WHEN USER INTERACTS
                  if (errors.managerId) {
                    setErrors((prev) => ({ ...prev, managerId: "" }));
                  }
                }}
                onFocus={() => {
                  refetchManagers();
                  setShowDropdown(true);
                }}
                className={`w-full mt-1 border border-gray-300 ${
                 ( isManager || isEdit) ? "cursor-not-allowed bg-gray-100" : ""
                } rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]`}
              />
              {errors.managerId && (
                <p className="text-red-500 text-xs mt-1">{errors.managerId}</p>
              )}

              {managerSearch && (
                <button
                  type="button"
                  onClick={() => {
                    setManagerSearch("");
                    setForm({ ...form, managerId: "" });
                  }}
                  className="absolute right-3 top-12 -translate-y-1/2 text-gray-400 hover:text-gray-700 "
                >
                  {(isManager || isEdit) ? "" : "✕"}
                </button>
              )}

              {showDropdown && (
                <div
                  className="absolute w-full bg-white border border-gray-300 rounded-md mt-1
                max-h-56 overflow-y-auto shadow-lg z-50"
                >
                  {isManagersLoading && (
                    <div className="p-3 animate-pulse">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded"></div>
                    </div>
                  )}

                  {!isManagersLoading && filteredManagers.length === 0 && (
                    <div className="px-4 py-3 text-gray-500 text-sm">
                      No results found
                    </div>
                  )}

                  {filteredManagers.map((m: any, index: number) => (
                    <div
                      key={m.id}
                      onClick={() => handleSelectManager(m)}
                      onMouseEnter={() => setHighlightIndex(index)}
                      className={`px-4 py-2 cursor-pointer text-sm
                      ${
                        highlightIndex === index
                          ? "bg-[#f4e8ff] text-[#5b00b2] border-l-4 border-[#5b00b2] font-medium"
                          : "hover:bg-gray-100"
                      }`}
                    >
                      <div className="font-medium">{m.fullName}</div>
                      <div className="text-xs text-gray-500">{m.email}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            {isManager && (
              <div className="w-full max-w-2xl">
                <label className="block text-sm mb-1">Users</label>
                <div className="relative" ref={dropdownRefUser}>
                  {/* Input Box */}
                  <div
                    className="w-full border rounded-md p-2 flex items-center flex-wrap gap-2 cursor-pointer text-sm"
                    onClick={() => {
                      refetch();
                      setOpen(!open);
                    }}
                  >
                    {/* Tags */}
                    {selected?.length > 0 ? (
                      selected.map((item) => (
                        <span
                          key={item.id}
                          className="bg-gray-200 text-sm px-2 py-1 rounded flex items-center gap-1"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {item.fullName}
                          <X
                            size={14}
                            className="cursor-pointer"
                            onClick={() => removeTag(item.id)}
                          />
                        </span>
                      ))
                    ) : (
                      <span className="text-gray-400 text-sm">
                        Select patients...
                      </span>
                    )}

                    {/* Right Icons */}
                    <span className="ml-auto flex items-center gap-3 pr-1">
                      {/* Clear All button */}
                      {selected?.length > 0 && (
                        <X
                          size={16}
                          className="cursor-pointer text-gray-400 hover:text-black"
                          onClick={() => setSelected([])}
                        />
                      )}

                      <ChevronDown size={18} className="text-gray-600" />
                    </span>
                  </div>

                  {/* Dropdown */}
                  {open && (
                    <div className="absolute w-full border bg-white shadow-md rounded-md mt-1 max-h-60 overflow-y-auto z-50">
                      {patientResponse?.data?.users?.map((item) => (
                        <label
                          key={item.id}
                          className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-100"
                        >
                          <input
                            type="checkbox"
                            checked={selected.some((s) => s.id === item.id)}
                            onChange={() => handleCheckboxChange(item)}
                            onClick={(e) => e.stopPropagation()}
                          />
                          <span className="text-sm">{item.fullName}</span>
                        </label>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
            {/* BUDGET + CURRENCY */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <RequiredLabel label="Budget" />
                <input
                  type="number"
                  name="budgetBaseline"
                  placeholder="0"
                  value={form.budgetBaseline}
                  onChange={handleChange}
                  disabled={isManager}
                  className={`w-full mt-1 border border-gray-300 ${
                    isManager ? "cursor-not-allowed bg-gray-100" : ""
                  } rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]`}
                />
                {errors.budgetBaseline && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.budgetBaseline}
                  </p>
                )}
              </div>

              <div>
                <RequiredLabel label="Currency" />
                <select
                  name="currency"
                  disabled={isManager}
                  value={form.currency}
                  onChange={handleChange}
                  className={`w-full mt-1 border border-gray-300 ${
                    isManager ? "cursor-not-allowed bg-gray-100" : ""
                  } rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]`}
                >
                  {/* <option value="INR">INR</option>
                  <option value="USD">USD</option> */}
                  <option value="ETB">ETB</option>
                </select>
              </div>
            </div>

            {/* DATES */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <RequiredLabel label="Start Date" />
                <div className="relative">
                  <input
                    type="date"
                    name="startDate"
                    value={form.startDate}
                    onChange={handleChange}
                    className="w-full mt-1 border border-gray-300 rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]"
                  />
                  <Calendar
                    onClick={(e) =>
                      (
                        e.currentTarget
                          .previousElementSibling as HTMLInputElement
                      )?.showPicker?.()
                    }
                    size={16}
                    className="absolute right-3 top-6 -translate-y-1/2 text-gray-400 cursor-pointer"
                  />
                  {errors.startDate && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.startDate}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <RequiredLabel label="End Date" />
                <div className="relative">
                  <input
                    type="date"
                    name="endDate"
                    value={form.endDate}
                    onChange={handleChange}
                    onClick={(e) =>
                      (
                        e.currentTarget
                          .previousElementSibling as HTMLInputElement
                      )?.showPicker?.()
                    }
                    className="w-full mt-1 border border-gray-300 rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]"
                  />
                  <Calendar
                    size={16}
                    onClick={(e) =>
                      (
                        e.currentTarget
                          .previousElementSibling as HTMLInputElement
                      )?.showPicker?.()
                    }
                    className="absolute right-3 top-6 -translate-y-1/2 text-gray-400 cursor-pointer"
                  />
                  {errors.endDate && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.endDate}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* CITY + COUNTRY */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <RequiredLabel label="City" />
                <input
                  type="text"
                  name="city"
                  value={form.city}
                  onChange={handleChange}
                  placeholder="City"
                  className="w-full mt-1 border border-gray-300 rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]"
                />
                {errors.city && (
                  <p className="text-red-500 text-xs mt-1">{errors.city}</p>
                )}
              </div>

              <div>
                <RequiredLabel label="Country" />
                <input
                  type="text"
                  name="country"
                  value={form.country}
                  onChange={handleChange}
                  placeholder="Country"
                  className="w-full mt-1 border border-gray-300 rounded-md p-2 text-sm
  focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]"
                />
                {errors.country && (
                  <p className="text-red-500 text-xs mt-1">{errors.country}</p>
                )}
              </div>
            </div>

            {/* ADDRESS */}
            <div>
              <RequiredLabel label="Address" />
              <input
                type="text"
                name="address"
                value={form.address}
                onChange={handleChange}
                placeholder="Full address"
                className="w-full mt-1 border border-gray-300 rounded-md p-2 text-sm
         focus:outline-none focus:ring-1 focus:ring-[#5b00b2] focus:border-[#5b00b2]"
              />
              {errors.address && (
                <p className="text-red-500 text-xs mt-1">{errors.address}</p>
              )}
            </div>

            {/* BUTTONS */}
            <div className="flex justify-end gap-3 mt-6">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm text-gray-700
              hover:bg-[#facf6c] hover:border-[#fe9a00]"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-[#5b00b2] text-white rounded-md text-sm hover:bg-[#4b0082]
              disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {isEdit
                  ? loading
                    ? "Updating..."
                    : "Update Project"
                  : loading
                  ? "Creating..."
                  : "Create Project"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default AddEditProjectModal;
