import GRNDashboard from "./GRNDashboard";
import GRNTab from "./GRNTab";

const GoodsReceivedNote = () => {
  return (
    <div>
      <GRNDashboard />
      <GRNTab />
    </div>
  );
};

export default GoodsReceivedNote;
