import BOQDashboard from "./BOQDashboard";
import { BOQTab } from "./BOQTab";

const BOQ = () => {
  return (
    <div>
      <BOQDashboard />
      <BOQTab />
    </div>
  );
};

export default BOQ;
