const InventoryForecast = () => {
  return (
    <div>InventoryForecast</div>
  )
}

export default InventoryForecast