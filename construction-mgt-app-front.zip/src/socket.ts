// // socket.ts
// import { io, Socket } from "socket.io-client";
// let socket: Socket | null = null;

// export const connectSocket = (role: string) => {
//   socket = io(
//     "https://sean-clannish-interjectionally.ngrok-free.dev/api/realtime",
//     {
//       query: { role },
//       transports: ["websocket"],
//     }
//   );

//   return socket;
// };

// export const getSocket = () => socket;
// socket.ts
// import { io, Socket } from "socket.io-client";

// const SOCKET_URL = "https://sean-clannish-interjectionally.ngrok-free.dev/api"; // e.g. https://api.example.com

// let socket: Socket | null = null;

// export const connectSocket = (userId: string, role: string): Socket => {
//   if (!socket) {
//     socket = io(`${SOCKET_URL}/realtime`, {
//       transports: ["websocket"],
//       query: {
//         userId,
//         role, // SUPER_ADMIN | MANAGER | USER
//       },
//     });
//   }

//   return socket;
// };

// export const disconnectSocket = () => {
//   if (socket) {
//     socket.disconnect();
//     socket = null;
//   }
// };

// export const getSocket = () => socket;
import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

export const connectSocket = (userId: string, role: string): Socket => {
  if (socket) return socket;

  socket = io(`${import.meta.env.VITE_API_BASE_URL}/realtime`, {
    transports: ["websocket"],
    query: {
      userId,
      role,
    },
  });

  socket.on("connect", () => {
    console.log("🟢 Socket connected:", socket?.id);
  });

  socket.on("disconnect", () => {
    console.log("🔴 Socket disconnected");
  });

  return socket;
};

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
