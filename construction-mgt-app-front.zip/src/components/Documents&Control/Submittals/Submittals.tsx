import SubmittalDashboard from "./SubmittalDashboard";
import SubmittalsTab from "./SubmittalsTab";

const Submittals = () => {
  return (
    <div>
      <SubmittalsTab />
    </div>
  );
};

export default Submittals;
