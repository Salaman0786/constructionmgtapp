// import { useEffect, useRef } from "react";
// import AppRoutes from "./routes/AppRoutes";
// import { useSelector } from "react-redux";
// import { connectSocket } from "./socket";
// import { showSuccess } from "./utils/toast";
// import { NOTIFICATION_EVENT } from "./notification-events";

// export default function App() {
//   const authUser = useSelector((state: any) => state.auth.user);
//   const hasConnected = useRef(false);

//   useEffect(() => {
//     if (!authUser?.id || !authUser?.role?.name) return;

//     if (hasConnected.current) return; // ✅ prevent double connect

//     hasConnected.current = true;

//     const socket = connectSocket(authUser.id, authUser.role.name);
//     console.log(socket, hasConnected, authUser, "hasConnectedgot");
//     socket.on(NOTIFICATION_EVENT.PUSH, (notification) => {
//       console.log("🔔 New Notification:", notification);
//       showSuccess(notification.title || "connected succesfully websocket");
//     });

//     return () => {
//       // ❌ DO NOT disconnect in dev StrictMode
//     };
//   }, [authUser?.id, authUser?.role?.name]);

//   return (
//     <>
//       <AppRoutes />
//     </>
//   );
// }
import { useEffect, useRef } from "react";
import { useSelector } from "react-redux";
import AppRoutes from "./routes/AppRoutes";
import { connectSocket, disconnectSocket } from "./socket";
import { NOTIFICATION_EVENT } from "./notification-events";
import { showSuccess } from "./utils/toast";

export default function App() {
  const authUser = useSelector((state: any) => state.auth.user);
  const hasConnected = useRef(false);

  useEffect(() => {
    if (!authUser?.id || !authUser?.role?.name) return;
    if (hasConnected.current) return;

    hasConnected.current = true;

    const socket = connectSocket(authUser.id, authUser.role.name);

    socket.on(NOTIFICATION_EVENT.PUSH, (notification) => {
      console.log("🔔 Notification:", notification);
      showSuccess(notification.title);
    });
  }, [authUser?.id, authUser?.role?.name]);

  useEffect(() => {
    if (!authUser) {
      disconnectSocket();
      hasConnected.current = false;
    }
  }, [authUser]);

  return <AppRoutes />;
}
