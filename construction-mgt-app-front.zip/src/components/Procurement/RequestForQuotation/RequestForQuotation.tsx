import RFQDashboard from "./RFQDashboard";
import RFQTab from "./RFQTab";
const RequestForQuotation = () => {
  return (
    <div>
      <RFQDashboard />
      <RFQTab />
    </div>
  );
};

export default RequestForQuotation;
