import PODashboard from "./PODashboard"
import POTab  from "./POTab"
const PurchaseOrders = () => {
  return <div>
    <PODashboard />
    <POTab />
  </div>;
};

export default PurchaseOrders;
