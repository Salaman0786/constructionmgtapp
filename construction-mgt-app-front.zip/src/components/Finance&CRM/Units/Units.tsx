import UnitsHeader from "./UnitsHeader";
import { UnitsTab } from "./UnitsTab";

const Units = () => {
  return (
    <div>
      <UnitsHeader />
      <UnitsTab />
    </div>
  );
};

export default Units;
