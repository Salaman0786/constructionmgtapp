const ReorderAlerts = () => {
  return (
    <div>ReorderAlerts</div>
  )
}

export default ReorderAlerts